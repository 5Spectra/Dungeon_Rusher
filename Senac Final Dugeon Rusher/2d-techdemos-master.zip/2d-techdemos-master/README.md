# 2d-techdemos

2d-techdemos is a repository containing helpful examples of 2D features with scenes and assets. 

All items in the repository are grouped by use for a feature and are listed below.

### Tilemap

- **Brick** - A Breakout style game using Tilemap and Physics 2D. This example makes use of the Physics2D collision contacts to determine which cell in the Tilemap is hit when there is a collision.

For use with Unity 2017.2b02 onwards.